package com.securechat.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.securechat.R;
import com.securechat.adapters.MessageAdapter;
import com.securechat.models.Message;
import com.securechat.utils.CryptoUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends AppCompatActivity {

    private RecyclerView recyclerMessages;
    private EditText etMessage;
    private MessageAdapter adapter;
    private List<Message> messages = new ArrayList<>();
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String conversationId;
    private String otherUserId;
    private boolean isHidden;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        conversationId = getIntent().getStringExtra("conversation_id");
        String otherUserName = getIntent().getStringExtra("other_user_name");
        otherUserId = getIntent().getStringExtra("other_user_id");
        isHidden = getIntent().getBooleanExtra("hidden", false);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(otherUserName != null ? otherUserName : "Chat");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerMessages = findViewById(R.id.recyclerMessages);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recyclerMessages.setLayoutManager(layoutManager);

        String currentUid = mAuth.getCurrentUser().getUid();
        adapter = new MessageAdapter(messages, currentUid);
        recyclerMessages.setAdapter(adapter);

        etMessage = findViewById(R.id.etMessage);
        ImageButton btnSend = findViewById(R.id.btnSend);
        btnSend.setOnClickListener(v -> sendMessage());

        // Create conversation doc if needed
        if (conversationId == null) {
            createConversation();
        } else {
            listenForMessages();
        }
    }

    private void createConversation() {
        String currentUid = mAuth.getCurrentUser().getUid();
        // Build deterministic conversation ID from both UIDs
        String[] uids = {currentUid, otherUserId};
        java.util.Arrays.sort(uids);
        conversationId = uids[0] + "_" + uids[1] + (isHidden ? "_hidden" : "");
        listenForMessages();
    }

    private void listenForMessages() {
        db.collection("conversations")
                .document(conversationId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;
                    messages.clear();
                    for (QueryDocumentSnapshot doc : snapshots) {
                        Message msg = doc.toObject(Message.class);
                        msg.setId(doc.getId());
                        // Decrypt message body
                        try {
                            msg.setText(CryptoUtils.decrypt(msg.getEncryptedText(), conversationId));
                        } catch (Exception ex) {
                            msg.setText("[encrypted]");
                        }
                        messages.add(msg);
                    }
                    adapter.notifyDataSetChanged();
                    if (!messages.isEmpty()) {
                        recyclerMessages.scrollToPosition(messages.size() - 1);
                    }
                });
    }

    private void sendMessage() {
        String text = etMessage.getText().toString().trim();
        if (text.isEmpty()) return;

        String currentUid = mAuth.getCurrentUser().getUid();
        String encryptedText;
        try {
            encryptedText = CryptoUtils.encrypt(text, conversationId);
        } catch (Exception e) {
            Toast.makeText(this, "Encryption error", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> msgMap = new HashMap<>();
        msgMap.put("senderId", currentUid);
        msgMap.put("encryptedText", encryptedText);
        msgMap.put("timestamp", System.currentTimeMillis());

        db.collection("conversations")
                .document(conversationId)
                .collection("messages")
                .add(msgMap)
                .addOnSuccessListener(ref -> {
                    etMessage.setText("");
                    // Update conversation's last message
                    Map<String, Object> update = new HashMap<>();
                    update.put("lastMessage", "🔒 Encrypted message");
                    update.put("lastTimestamp", System.currentTimeMillis());
                    update.put("members", java.util.Arrays.asList(currentUid, otherUserId));
                    update.put("hidden", isHidden);
                    if (update.get("hidden") == null) update.put("hidden", false);
                    db.collection("conversations").document(conversationId).set(update, com.google.firebase.firestore.SetOptions.merge());
                });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
