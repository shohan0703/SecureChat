package com.securechat.adapters;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.securechat.R;
import com.securechat.models.Message;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    private final List<Message> messages;
    private final String currentUserId;

    public MessageAdapter(List<Message> messages, String currentUserId) {
        this.messages = messages;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        Message msg = messages.get(position);
        boolean isMine = currentUserId.equals(msg.getSenderId());

        holder.tvMessage.setText(msg.getText());

        // Align bubble: right for sent, left for received
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) holder.tvMessage.getLayoutParams();
        if (isMine) {
            holder.tvMessage.setBackgroundResource(R.drawable.bg_bubble_sent);
            params.gravity = Gravity.END;
        } else {
            holder.tvMessage.setBackgroundResource(R.drawable.bg_bubble_received);
            params.gravity = Gravity.START;
        }
        holder.tvMessage.setLayoutParams(params);

        // Timestamp
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        holder.tvTime.setText(sdf.format(new Date(msg.getTimestamp())));

        LinearLayout.LayoutParams timeParams = (LinearLayout.LayoutParams) holder.tvTime.getLayoutParams();
        timeParams.gravity = isMine ? Gravity.END : Gravity.START;
        holder.tvTime.setLayoutParams(timeParams);
    }

    @Override
    public int getItemCount() { return messages.size(); }

    static class MessageViewHolder extends RecyclerView.ViewHolder {
        TextView tvMessage, tvTime;
        MessageViewHolder(View view) {
            super(view);
            tvMessage = view.findViewById(R.id.tvMessage);
            tvTime = view.findViewById(R.id.tvTime);
        }
    }
}
