package com.securechat.activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.securechat.R;
import com.securechat.adapters.ConversationAdapter;
import com.securechat.models.Conversation;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class HiddenChatActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ConversationAdapter adapter;
    private List<Conversation> conversations = new ArrayList<>();
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // reuse same layout

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Hidden Chats");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerView = findViewById(R.id.recyclerConversations);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ConversationAdapter(conversations, conversation -> {
            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("conversation_id", conversation.getId());
            intent.putExtra("other_user_name", conversation.getOtherUserName());
            intent.putExtra("other_user_id", conversation.getOtherUserId());
            intent.putExtra("hidden", true);
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        // Hide the hidden trigger button in this screen
        findViewById(R.id.tvHiddenTrigger).setVisibility(android.view.View.GONE);

        loadHiddenConversations();
    }

    private void loadHiddenConversations() {
        String currentUid = mAuth.getCurrentUser().getUid();
        db.collection("conversations")
                .whereArrayContains("members", currentUid)
                .whereEqualTo("hidden", true)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;
                    conversations.clear();
                    for (QueryDocumentSnapshot doc : snapshots) {
                        Conversation conv = doc.toObject(Conversation.class);
                        conv.setId(doc.getId());
                        List<String> members = (List<String>) doc.get("members");
                        List<String> memberNames = (List<String>) doc.get("memberNames");
                        if (members != null && memberNames != null) {
                            int otherIndex = members.indexOf(currentUid) == 0 ? 1 : 0;
                            if (otherIndex < memberNames.size()) {
                                conv.setOtherUserName(memberNames.get(otherIndex));
                                conv.setOtherUserId(members.get(otherIndex));
                            }
                        }
                        conversations.add(conv);
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
