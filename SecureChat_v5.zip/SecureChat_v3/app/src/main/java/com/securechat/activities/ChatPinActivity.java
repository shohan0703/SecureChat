package com.securechat.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.securechat.R;

/**
 * Used to SET or VERIFY a per-chat PIN.
 * Extras:
 *   conversation_id (String) - required
 *   mode: "set" or "verify"
 * On verify success -> RESULT_OK
 */
public class ChatPinActivity extends AppCompatActivity {

    private static final String PREFS = "chat_pins";

    public static boolean hasChatPin(Context ctx, String convId) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(convId);
    }

    public static boolean verifyChatPin(Context ctx, String convId, String pin) {
        String stored = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(convId, null);
        return pin.equals(stored);
    }

    public static void removeChatPin(Context ctx, String convId) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(convId).apply();
    }

    private String conversationId;
    private String mode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_pin);

        conversationId = getIntent().getStringExtra("conversation_id");
        mode = getIntent().getStringExtra("mode"); // "set" or "verify"

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        TextView tvTitle = findViewById(R.id.tvTitle);
        EditText etPin = findViewById(R.id.etPin);
        Button btnConfirm = findViewById(R.id.btnConfirm);

        if ("set".equals(mode)) {
            getSupportActionBar().setTitle("Set Chat PIN");
            tvTitle.setText("Set a PIN to hide this chat");
            btnConfirm.setText("Set PIN");
            btnConfirm.setOnClickListener(v -> {
                String pin = etPin.getText().toString().trim();
                if (pin.length() < 4) {
                    Toast.makeText(this, "PIN must be at least 4 digits", Toast.LENGTH_SHORT).show();
                    return;
                }
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putString(conversationId, pin).apply();
                Toast.makeText(this, "Chat PIN set", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            });
        } else {
            getSupportActionBar().setTitle("Enter PIN");
            tvTitle.setText("Enter PIN to access hidden chat");
            btnConfirm.setText("Unlock");
            btnConfirm.setOnClickListener(v -> {
                String pin = etPin.getText().toString().trim();
                if (verifyChatPin(this, conversationId, pin)) {
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show();
                    etPin.setText("");
                }
            });
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        setResult(RESULT_CANCELED);
        finish();
        return true;
    }
}
