package com.securechat.adapters;

import android.app.AlertDialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.securechat.R;
import com.securechat.activities.ChatPinActivity;
import com.securechat.models.Conversation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class ConversationAdapter extends RecyclerView.Adapter<ConversationAdapter.ConversationViewHolder> {

    public interface OnConversationClickListener {
        void onClick(Conversation conversation);
    }

    private final List<Conversation> conversations;
    private final OnConversationClickListener listener;

    public ConversationAdapter(List<Conversation> conversations, OnConversationClickListener listener) {
        this.conversations = conversations;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ConversationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_conversation, parent, false);
        return new ConversationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ConversationViewHolder holder, int position) {
        Conversation conv = conversations.get(position);
        holder.tvName.setText(conv.getOtherUserName() != null ? conv.getOtherUserName() : "Chat");
        holder.tvLastMessage.setText(conv.getLastMessage() != null ? conv.getLastMessage() : "No messages yet");

        if (conv.getLastTimestamp() > 0) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd", Locale.getDefault());
            holder.tvTime.setText(sdf.format(new Date(conv.getLastTimestamp())));
        }

        // Avatar initial
        if (conv.getOtherUserName() != null && !conv.getOtherUserName().isEmpty()) {
            holder.tvAvatar.setText(String.valueOf(conv.getOtherUserName().charAt(0)).toUpperCase());
        }

        // Other user profile pic
        if (conv.getOtherUserProfileUrl() != null && !conv.getOtherUserProfileUrl().isEmpty()) {
            holder.civAvatar.setVisibility(View.VISIBLE);
            holder.tvAvatar.setVisibility(View.GONE);
            Glide.with(holder.civAvatar.getContext())
                    .load(conv.getOtherUserProfileUrl())
                    .transform(new CircleCrop())
                    .into(holder.civAvatar);
        } else {
            holder.civAvatar.setVisibility(View.GONE);
            holder.tvAvatar.setVisibility(View.VISIBLE);
        }

        // PIN lock indicator
        boolean hasChatPin = ChatPinActivity.hasChatPin(holder.itemView.getContext(), conv.getId());
        holder.tvPinIndicator.setVisibility(hasChatPin ? View.VISIBLE : View.GONE);

        holder.itemView.setOnClickListener(v -> listener.onClick(conv));

        // Long press: hide/unhide with PIN
        holder.itemView.setOnLongClickListener(v -> {
            boolean pinExists = ChatPinActivity.hasChatPin(v.getContext(), conv.getId());
            String[] options = pinExists
                    ? new String[]{"Remove chat PIN", "Cancel"}
                    : new String[]{"Hide with PIN", "Cancel"};

            new AlertDialog.Builder(v.getContext())
                    .setTitle(conv.getOtherUserName())
                    .setItems(options, (dialog, which) -> {
                        if (which == 0) {
                            if (pinExists) {
                                ChatPinActivity.removeChatPin(v.getContext(), conv.getId());
                                notifyItemChanged(position);
                            } else {
                                // Launch set PIN
                                Intent intent = new Intent(v.getContext(), ChatPinActivity.class);
                                intent.putExtra("conversation_id", conv.getId());
                                intent.putExtra("mode", "set");
                                v.getContext().startActivity(intent);
                            }
                        }
                    })
                    .show();
            return true;
        });
    }

    @Override
    public int getItemCount() { return conversations.size(); }

    static class ConversationViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvLastMessage, tvTime, tvAvatar, tvPinIndicator;
        CircleImageView civAvatar;

        ConversationViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvLastMessage = view.findViewById(R.id.tvLastMessage);
            tvTime = view.findViewById(R.id.tvTime);
            tvAvatar = view.findViewById(R.id.tvAvatar);
            tvPinIndicator = view.findViewById(R.id.tvPinIndicator);
            civAvatar = view.findViewById(R.id.civAvatar);
        }
    }
}
