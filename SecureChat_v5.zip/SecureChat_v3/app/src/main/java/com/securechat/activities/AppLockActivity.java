package com.securechat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.securechat.R;
import com.securechat.utils.PinManager;
import com.google.firebase.auth.FirebaseAuth;

public class AppLockActivity extends AppCompatActivity {

    private TextView tvPin;
    private StringBuilder pinInput = new StringBuilder();
    private boolean isHiddenChatMode = false;
    private PinManager pinManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_lock);

        pinManager = new PinManager(this);
        tvPin = findViewById(R.id.tvPinDisplay);

        isHiddenChatMode = getIntent().getBooleanExtra("hidden_chat_mode", false);

        // If no PIN set yet, go to setup
        if (!isHiddenChatMode && !pinManager.hasAppPin()) {
            startActivity(new Intent(this, SetupPinActivity.class));
            finish();
            return;
        }

        TextView tvTitle = findViewById(R.id.tvLockTitle);
        tvTitle.setText(isHiddenChatMode ? "Enter Hidden Chat PIN" : "Enter PIN to unlock");

        setupKeypad();
    }

    private void setupKeypad() {
        int[] numIds = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
                R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};

        for (int id : numIds) {
            Button btn = findViewById(id);
            btn.setOnClickListener(v -> {
                if (pinInput.length() < 4) {
                    pinInput.append(((Button) v).getText().toString());
                    updatePinDisplay();
                    if (pinInput.length() == 4) verifyPin();
                }
            });
        }

        findViewById(R.id.btnBackspace).setOnClickListener(v -> {
            if (pinInput.length() > 0) {
                pinInput.deleteCharAt(pinInput.length() - 1);
                updatePinDisplay();
            }
        });
    }

    private void updatePinDisplay() {
        StringBuilder dots = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            dots.append(i < pinInput.length() ? "●" : "○");
            if (i < 3) dots.append("  ");
        }
        tvPin.setText(dots.toString());
    }

    private void verifyPin() {
        String entered = pinInput.toString();
        pinInput.setLength(0);
        updatePinDisplay();

        if (isHiddenChatMode) {
            if (pinManager.verifyHiddenPin(entered)) {
                Intent intent = new Intent(this, HiddenChatActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show();
            }
        } else {
            if (pinManager.verifyAppPin(entered)) {
                // Check if user is logged in
                if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                    startActivity(new Intent(this, MainActivity.class));
                } else {
                    startActivity(new Intent(this, LoginActivity.class));
                }
                finish();
            } else {
                Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
