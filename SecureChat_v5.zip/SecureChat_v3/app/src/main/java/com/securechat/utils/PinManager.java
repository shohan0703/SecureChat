package com.securechat.utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

public class PinManager {

    private static final String PREFS_NAME = "secure_prefs";
    private static final String KEY_APP_PIN = "app_pin_hash";
    private static final String KEY_HIDDEN_PIN = "hidden_pin_hash";

    private final SharedPreferences prefs;

    public PinManager(Context context) {
        SharedPreferences tempPrefs;
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            tempPrefs = EncryptedSharedPreferences.create(
                    context,
                    PREFS_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            // Fallback to regular prefs if encrypted not available
            tempPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        }
        prefs = tempPrefs;
    }

    private String hash(String pin) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(pin.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return pin; // fallback
        }
    }

    public void saveAppPin(String pin) {
        prefs.edit().putString(KEY_APP_PIN, hash(pin)).apply();
    }

    public boolean hasAppPin() {
        return prefs.contains(KEY_APP_PIN);
    }

    public boolean verifyAppPin(String pin) {
        String stored = prefs.getString(KEY_APP_PIN, null);
        return stored != null && stored.equals(hash(pin));
    }

    public void saveHiddenPin(String pin) {
        prefs.edit().putString(KEY_HIDDEN_PIN, hash(pin)).apply();
    }

    public boolean hasHiddenPin() {
        return prefs.contains(KEY_HIDDEN_PIN);
    }

    public boolean verifyHiddenPin(String pin) {
        String stored = prefs.getString(KEY_HIDDEN_PIN, null);
        return stored != null && stored.equals(hash(pin));
    }
}
