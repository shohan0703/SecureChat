package com.securechat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.securechat.R;
import com.securechat.adapters.UserSearchAdapter;
import com.securechat.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class NewChatActivity extends AppCompatActivity {

    private RecyclerView recyclerUsers;
    private UserSearchAdapter adapter;
    private List<User> users = new ArrayList<>();
    private ProgressBar progressBar;
    private TextView tvHint;
    private FirebaseFirestore db;
    private String currentUid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_chat);

        db = FirebaseFirestore.getInstance();
        currentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("New Chat");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        progressBar = findViewById(R.id.progressBar);
        tvHint = findViewById(R.id.tvHint);
        recyclerUsers = findViewById(R.id.recyclerUsers);
        recyclerUsers.setLayoutManager(new LinearLayoutManager(this));

        adapter = new UserSearchAdapter(users, user -> openChat(user));
        recyclerUsers.setAdapter(adapter);

        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().trim();
                if (query.length() >= 3) {
                    searchUsers(query);
                    tvHint.setVisibility(View.GONE);
                } else {
                    users.clear();
                    adapter.notifyDataSetChanged();
                    tvHint.setVisibility(View.VISIBLE);
                }
            }
            public void afterTextChanged(Editable s) {}
        });

        // Show hint by default, do NOT load all users
        tvHint.setVisibility(View.VISIBLE);
    }

    private void searchUsers(String query) {
        progressBar.setVisibility(View.VISIBLE);
        String queryLower = query.toLowerCase();

        db.collection("users")
                .get()
                .addOnSuccessListener(snapshots -> {
                    users.clear();
                    for (QueryDocumentSnapshot doc : snapshots) {
                        User user = doc.toObject(User.class);
                        user.setUid(doc.getId());
                        if (user.getUid().equals(currentUid)) continue;
                        // Match by username or userId
                        boolean matchName = user.getUsername() != null &&
                                user.getUsername().toLowerCase().contains(queryLower);
                        boolean matchId = user.getUid().toLowerCase().contains(queryLower);
                        if (matchName || matchId) {
                            users.add(user);
                        }
                    }
                    adapter.notifyDataSetChanged();
                    progressBar.setVisibility(View.GONE);
                    if (users.isEmpty()) {
                        tvHint.setText("No user found");
                        tvHint.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(e -> progressBar.setVisibility(View.GONE));
    }

    private void openChat(User user) {
        String[] uids = {currentUid, user.getUid()};
        java.util.Arrays.sort(uids);
        String convId = uids[0] + "_" + uids[1];

        db.collection("users").document(currentUid).get()
                .addOnSuccessListener(doc -> {
                    String myUsername = doc.getString("username");

                    java.util.Map<String, Object> convData = new java.util.HashMap<>();
                    convData.put("members", java.util.Arrays.asList(uids[0], uids[1]));
                    String name0 = uids[0].equals(currentUid) ? myUsername : user.getUsername();
                    String name1 = uids[1].equals(currentUid) ? myUsername : user.getUsername();
                    convData.put("memberNames", java.util.Arrays.asList(name0, name1));
                    convData.put("hidden", false);
                    convData.put("lastMessage", "");
                    convData.put("lastTimestamp", 0L);

                    db.collection("conversations").document(convId)
                            .set(convData, com.google.firebase.firestore.SetOptions.merge())
                            .addOnSuccessListener(unused -> {
                                Intent intent = new Intent(this, ChatActivity.class);
                                intent.putExtra("conversation_id", convId);
                                intent.putExtra("other_user_name", user.getUsername());
                                intent.putExtra("other_user_id", user.getUid());
                                startActivity(intent);
                                finish();
                            });
                });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
