package com.securechat.models;

import java.util.Map;

public class Message {
    private String id;
    private String senderId;
    private String encryptedText;
    private String text; // decrypted, not stored in DB
    private long timestamp;
    private String imageUrl;
    private String type;       // "text", "image", "voice"
    private Map<String, String> reactions; // userId -> emoji

    // Reply fields
    private String replyToId;           // ID of the message being replied to
    private String replyToText;         // preview text of replied message (encrypted)
    private String replyToSenderId;     // sender of replied message
    private String replyToDecryptedText; // local only, not stored

    // Voice fields
    private String voiceUrl;            // Firebase Storage URL
    private long voiceDuration;         // duration in seconds

    public Message() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }
    public String getEncryptedText() { return encryptedText; }
    public void setEncryptedText(String encryptedText) { this.encryptedText = encryptedText; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public Map<String, String> getReactions() { return reactions; }
    public void setReactions(Map<String, String> reactions) { this.reactions = reactions; }

    public String getReplyToId() { return replyToId; }
    public void setReplyToId(String replyToId) { this.replyToId = replyToId; }
    public String getReplyToText() { return replyToText; }
    public void setReplyToText(String replyToText) { this.replyToText = replyToText; }
    public String getReplyToSenderId() { return replyToSenderId; }
    public void setReplyToSenderId(String replyToSenderId) { this.replyToSenderId = replyToSenderId; }
    public String getReplyToDecryptedText() { return replyToDecryptedText; }
    public void setReplyToDecryptedText(String replyToDecryptedText) { this.replyToDecryptedText = replyToDecryptedText; }

    public String getVoiceUrl() { return voiceUrl; }
    public void setVoiceUrl(String voiceUrl) { this.voiceUrl = voiceUrl; }
    public long getVoiceDuration() { return voiceDuration; }
    public void setVoiceDuration(long voiceDuration) { this.voiceDuration = voiceDuration; }
}
