package com.securechat.models;

import java.util.List;

public class Conversation {
    private String id;
    private List<String> members;
    private List<String> memberNames;
    private List<String> memberProfileUrls;
    private String lastMessage;
    private long lastTimestamp;
    private boolean hidden;
    private String otherUserName;
    private String otherUserId;
    private String otherUserProfileUrl;

    public Conversation() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public List<String> getMembers() { return members; }
    public void setMembers(List<String> members) { this.members = members; }
    public List<String> getMemberNames() { return memberNames; }
    public void setMemberNames(List<String> memberNames) { this.memberNames = memberNames; }
    public List<String> getMemberProfileUrls() { return memberProfileUrls; }
    public void setMemberProfileUrls(List<String> urls) { this.memberProfileUrls = urls; }
    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }
    public long getLastTimestamp() { return lastTimestamp; }
    public void setLastTimestamp(long lastTimestamp) { this.lastTimestamp = lastTimestamp; }
    public boolean isHidden() { return hidden; }
    public void setHidden(boolean hidden) { this.hidden = hidden; }
    public String getOtherUserName() { return otherUserName; }
    public void setOtherUserName(String otherUserName) { this.otherUserName = otherUserName; }
    public String getOtherUserId() { return otherUserId; }
    public void setOtherUserId(String otherUserId) { this.otherUserId = otherUserId; }
    public String getOtherUserProfileUrl() { return otherUserProfileUrl; }
    public void setOtherUserProfileUrl(String url) { this.otherUserProfileUrl = url; }
}
