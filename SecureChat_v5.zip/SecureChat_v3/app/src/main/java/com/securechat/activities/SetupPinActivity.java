package com.securechat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.securechat.R;
import com.securechat.utils.PinManager;
import com.google.firebase.auth.FirebaseAuth;

public class SetupPinActivity extends AppCompatActivity {

    private TextView tvPin, tvTitle;
    private StringBuilder pinInput = new StringBuilder();
    private String firstPin = null;
    private boolean isSettingHiddenPin;
    private PinManager pinManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_lock);

        pinManager = new PinManager(this);
        tvPin = findViewById(R.id.tvPinDisplay);
        tvTitle = findViewById(R.id.tvLockTitle);

        isSettingHiddenPin = getIntent().getBooleanExtra("hidden_pin", false);
        tvTitle.setText(isSettingHiddenPin ? "Set Hidden Chat PIN" : "Set App PIN");

        setupKeypad();
    }

    private void setupKeypad() {
        int[] numIds = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
                R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
        for (int id : numIds) {
            Button btn = findViewById(id);
            btn.setOnClickListener(v -> {
                if (pinInput.length() < 4) {
                    pinInput.append(((Button) v).getText().toString());
                    updatePinDisplay();
                    if (pinInput.length() == 4) handlePinEntry();
                }
            });
        }
        findViewById(R.id.btnBackspace).setOnClickListener(v -> {
            if (pinInput.length() > 0) {
                pinInput.deleteCharAt(pinInput.length() - 1);
                updatePinDisplay();
            }
        });
    }

    private void updatePinDisplay() {
        StringBuilder dots = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            dots.append(i < pinInput.length() ? "●" : "○");
            if (i < 3) dots.append("  ");
        }
        tvPin.setText(dots.toString());
    }

    private void handlePinEntry() {
        String entered = pinInput.toString();
        pinInput.setLength(0);
        updatePinDisplay();

        if (firstPin == null) {
            firstPin = entered;
            tvTitle.setText("Confirm PIN");
        } else {
            if (firstPin.equals(entered)) {
                if (isSettingHiddenPin) {
                    pinManager.saveHiddenPin(entered);
                    Toast.makeText(this, "Hidden PIN set!", Toast.LENGTH_SHORT).show();
                } else {
                    pinManager.saveAppPin(entered);
                    Toast.makeText(this, "PIN set!", Toast.LENGTH_SHORT).show();
                }
                // After setting app PIN, check login state
                if (!isSettingHiddenPin) {
                    if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                        startActivity(new Intent(this, MainActivity.class));
                    } else {
                        startActivity(new Intent(this, LoginActivity.class));
                    }
                }
                finish();
            } else {
                Toast.makeText(this, "PINs don't match. Try again.", Toast.LENGTH_SHORT).show();
                firstPin = null;
                tvTitle.setText(isSettingHiddenPin ? "Set Hidden Chat PIN" : "Set App PIN");
            }
        }
    }
}
