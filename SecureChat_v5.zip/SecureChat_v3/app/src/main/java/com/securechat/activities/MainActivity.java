package com.securechat.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.securechat.R;
import com.securechat.adapters.ConversationAdapter;
import com.securechat.models.Conversation;
import com.securechat.utils.PinManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ConversationAdapter adapter;
    private List<Conversation> conversations = new ArrayList<>();
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private PinManager pinManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        pinManager = new PinManager(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("SecureChat");

        recyclerView = findViewById(R.id.recyclerConversations);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ConversationAdapter(conversations, conversation -> {
            // Check per-chat PIN
            if (com.securechat.activities.ChatPinActivity.hasChatPin(this, conversation.getId())) {
                Intent pinIntent = new Intent(this, ChatPinActivity.class);
                pinIntent.putExtra("conversation_id", conversation.getId());
                pinIntent.putExtra("mode", "verify");
                pinIntent.putExtra("pending_conv_id", conversation.getId());
                pinIntent.putExtra("pending_other_name", conversation.getOtherUserName());
                pinIntent.putExtra("pending_other_id", conversation.getOtherUserId());
                startActivityForResult(pinIntent, 100);
                // Store pending conv
                pendingConversation = conversation;
            } else {
                openChat(conversation);
            }
        });
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabNewChat);
        fab.setOnClickListener(v -> startActivity(new Intent(this, NewChatActivity.class)));

        findViewById(R.id.tvHiddenTrigger).setOnClickListener(v -> openHiddenChat());

        loadConversations();
    }

    private Conversation pendingConversation;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && pendingConversation != null) {
            openChat(pendingConversation);
            pendingConversation = null;
        }
    }

    private void openChat(Conversation conversation) {
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("conversation_id", conversation.getId());
        intent.putExtra("other_user_name", conversation.getOtherUserName());
        intent.putExtra("other_user_id", conversation.getOtherUserId());
        startActivity(intent);
    }

    private void loadConversations() {
        String currentUid = mAuth.getCurrentUser().getUid();
        db.collection("conversations")
                .whereArrayContains("members", currentUid)
                .whereEqualTo("hidden", false)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;
                    conversations.clear();
                    for (QueryDocumentSnapshot doc : snapshots) {
                        Conversation conv = doc.toObject(Conversation.class);
                        conv.setId(doc.getId());
                        List<String> members = (List<String>) doc.get("members");
                        List<String> memberNames = (List<String>) doc.get("memberNames");
                        List<String> memberProfileUrls = (List<String>) doc.get("memberProfileUrls");
                        if (members != null && memberNames != null) {
                            int otherIndex = members.indexOf(currentUid) == 0 ? 1 : 0;
                            if (otherIndex < memberNames.size()) {
                                conv.setOtherUserName(memberNames.get(otherIndex));
                                conv.setOtherUserId(members.get(otherIndex));
                            }
                            if (memberProfileUrls != null && otherIndex < memberProfileUrls.size()) {
                                conv.setOtherUserProfileUrl(memberProfileUrls.get(otherIndex));
                            }
                        }
                        conversations.add(conv);
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private void openHiddenChat() {
        if (!pinManager.hasHiddenPin()) {
            Intent intent = new Intent(this, SetupPinActivity.class);
            intent.putExtra("hidden_pin", true);
            startActivity(intent);
        } else {
            Intent intent = new Intent(this, AppLockActivity.class);
            intent.putExtra("hidden_chat_mode", true);
            startActivity(intent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            mAuth.signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else if (item.getItemId() == R.id.action_change_pin) {
            startActivity(new Intent(this, SetupPinActivity.class));
        } else if (item.getItemId() == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}
