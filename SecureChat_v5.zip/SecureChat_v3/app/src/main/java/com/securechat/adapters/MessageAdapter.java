package com.securechat.adapters;

import android.app.AlertDialog;
import android.media.MediaPlayer;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.securechat.R;
import com.securechat.models.Message;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    public interface OnReactionListener {
        void onReact(Message message, String emoji);
    }

    public interface OnReplyListener {
        void onReply(Message message);
    }

    private final List<Message> messages;
    private final String currentUserId;
    private final OnReactionListener reactionListener;
    private final OnReplyListener replyListener;

    // Track which ViewHolder is currently playing voice
    private MediaPlayer activePlayer = null;
    private MessageViewHolder activeVoiceHolder = null;
    private Handler seekHandler = new Handler();

    private static final String[] EMOJI_OPTIONS = {"❤️", "😂", "👍", "😮", "😢", "🔥"};

    public MessageAdapter(List<Message> messages, String currentUserId,
                          OnReactionListener reactionListener, OnReplyListener replyListener) {
        this.messages = messages;
        this.currentUserId = currentUserId;
        this.reactionListener = reactionListener;
        this.replyListener = replyListener;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        Message msg = messages.get(position);
        boolean isMine = currentUserId.equals(msg.getSenderId());

        // --- Alignment helper ---
        int gravity = isMine ? Gravity.END : Gravity.START;

        // --- Reset visibility ---
        holder.tvMessage.setVisibility(View.GONE);
        holder.ivImage.setVisibility(View.GONE);
        holder.layoutVoice.setVisibility(View.GONE);
        holder.layoutReplyPreview.setVisibility(View.GONE);

        // --- Wrapper alignment ---
        LinearLayout.LayoutParams wrapParams = (LinearLayout.LayoutParams) holder.layoutBubbleWrapper.getLayoutParams();
        wrapParams.gravity = gravity;
        holder.layoutBubbleWrapper.setLayoutParams(wrapParams);

        // --- Reply preview inside bubble ---
        if (msg.getReplyToId() != null && !msg.getReplyToId().isEmpty()) {
            holder.layoutReplyPreview.setVisibility(View.VISIBLE);
            String preview = msg.getReplyToDecryptedText();
            if (preview == null || preview.isEmpty()) preview = "🔒 Voice message";
            holder.tvReplyText.setText(preview);
        }

        // --- Bubble background ---
        int bgRes = isMine ? R.drawable.bg_bubble_sent : R.drawable.bg_bubble_received;

        // --- Render by type ---
        if ("voice".equals(msg.getType())) {
            holder.layoutVoice.setVisibility(View.VISIBLE);
            holder.layoutVoice.setBackgroundResource(bgRes);
            long dur = msg.getVoiceDuration();
            holder.tvVoiceDuration.setText(formatDuration(dur));
            holder.seekVoice.setProgress(0);
            holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);

            holder.btnPlayVoice.setOnClickListener(v -> toggleVoicePlayback(holder, msg));

            holder.seekVoice.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    if (fromUser && activePlayer != null && activeVoiceHolder == holder) {
                        activePlayer.seekTo(p);
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });

        } else if ("image".equals(msg.getType()) && msg.getImageUrl() != null) {
            holder.ivImage.setVisibility(View.VISIBLE);
            Glide.with(holder.ivImage.getContext())
                    .load(msg.getImageUrl())
                    .placeholder(R.drawable.bg_bubble_received)
                    .into(holder.ivImage);
            LinearLayout.LayoutParams imgParams = (LinearLayout.LayoutParams) holder.ivImage.getLayoutParams();
            imgParams.gravity = gravity;
            holder.ivImage.setLayoutParams(imgParams);

        } else {
            holder.tvMessage.setVisibility(View.VISIBLE);
            holder.tvMessage.setText(msg.getText());
            holder.tvMessage.setBackgroundResource(bgRes);
        }

        // --- Timestamp ---
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        holder.tvTime.setText(sdf.format(new Date(msg.getTimestamp())));
        LinearLayout.LayoutParams timeParams = (LinearLayout.LayoutParams) holder.tvTime.getLayoutParams();
        timeParams.gravity = gravity;
        holder.tvTime.setLayoutParams(timeParams);

        // --- Reactions ---
        Map<String, String> reactions = msg.getReactions();
        if (reactions != null && !reactions.isEmpty()) {
            java.util.Map<String, Integer> counts = new java.util.LinkedHashMap<>();
            for (String emoji : reactions.values()) {
                counts.put(emoji, counts.getOrDefault(emoji, 0) + 1);
            }
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Integer> entry : counts.entrySet()) {
                sb.append(entry.getKey());
                if (entry.getValue() > 1) sb.append(entry.getValue());
                sb.append(" ");
            }
            holder.tvReactions.setText(sb.toString().trim());
            holder.tvReactions.setVisibility(View.VISIBLE);
            LinearLayout.LayoutParams reactParams = (LinearLayout.LayoutParams) holder.tvReactions.getLayoutParams();
            reactParams.gravity = gravity;
            holder.tvReactions.setLayoutParams(reactParams);
        } else {
            holder.tvReactions.setVisibility(View.GONE);
        }

        // --- Long press: react or reply ---
        View targetView = holder.layoutBubbleWrapper;
        targetView.setOnLongClickListener(v -> {
            showMessageActions(v, msg);
            return true;
        });

        // --- Swipe / tap on bubble: quick reply ---
        targetView.setOnClickListener(null); // reset
    }

    private void toggleVoicePlayback(MessageViewHolder holder, Message msg) {
        // If this holder is already playing, stop it
        if (activeVoiceHolder == holder && activePlayer != null) {
            stopActivePlayer();
            holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);
            holder.seekVoice.setProgress(0);
            holder.tvVoiceDuration.setText(formatDuration(msg.getVoiceDuration()));
            return;
        }

        // Stop any other playing
        stopActivePlayer();

        // Start new player
        MediaPlayer player = new MediaPlayer();
        try {
            player.setDataSource(msg.getVoiceUrl());
            player.prepareAsync();
            player.setOnPreparedListener(mp -> {
                mp.start();
                holder.seekVoice.setMax(mp.getDuration());
                holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_pause);
                activePlayer = mp;
                activeVoiceHolder = holder;
                updateSeekBar(holder, msg);
            });
            player.setOnCompletionListener(mp -> {
                holder.btnPlayVoice.setImageResource(android.R.drawable.ic_media_play);
                holder.seekVoice.setProgress(0);
                holder.tvVoiceDuration.setText(formatDuration(msg.getVoiceDuration()));
                stopActivePlayer();
            });
        } catch (IOException e) {
            player.release();
        }
    }

    private void updateSeekBar(MessageViewHolder holder, Message msg) {
        seekHandler.postDelayed(() -> {
            if (activePlayer != null && activeVoiceHolder == holder && activePlayer.isPlaying()) {
                int pos = activePlayer.getCurrentPosition();
                holder.seekVoice.setProgress(pos);
                int remaining = (int)(activePlayer.getDuration() - pos) / 1000;
                holder.tvVoiceDuration.setText(formatDuration(remaining));
                updateSeekBar(holder, msg);
            }
        }, 200);
    }

    private void stopActivePlayer() {
        seekHandler.removeCallbacksAndMessages(null);
        if (activePlayer != null) {
            if (activePlayer.isPlaying()) activePlayer.stop();
            activePlayer.release();
            activePlayer = null;
        }
        activeVoiceHolder = null;
    }

    private void showMessageActions(View anchor, Message msg) {
        String[] options = {"Reply", "❤️", "😂", "👍", "😮", "😢", "🔥"};
        new AlertDialog.Builder(anchor.getContext())
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        replyListener.onReply(msg);
                    } else {
                        reactionListener.onReact(msg, EMOJI_OPTIONS[which - 1]);
                    }
                })
                .show();
    }

    private String formatDuration(long seconds) {
        return String.format(Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60);
    }

    @Override
    public int getItemCount() { return messages.size(); }

    // Release player when adapter is recycled
    public void releasePlayer() {
        stopActivePlayer();
    }

    static class MessageViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutBubbleWrapper, layoutReplyPreview, layoutVoice;
        TextView tvMessage, tvTime, tvReactions, tvReplyText, tvVoiceDuration;
        ImageView ivImage;
        ImageButton btnPlayVoice;
        SeekBar seekVoice;

        MessageViewHolder(View view) {
            super(view);
            layoutBubbleWrapper = view.findViewById(R.id.layoutBubbleWrapper);
            layoutReplyPreview = view.findViewById(R.id.layoutReplyPreview);
            layoutVoice = view.findViewById(R.id.layoutVoice);
            tvMessage = view.findViewById(R.id.tvMessage);
            tvTime = view.findViewById(R.id.tvTime);
            tvReactions = view.findViewById(R.id.tvReactions);
            tvReplyText = view.findViewById(R.id.tvReplyText);
            ivImage = view.findViewById(R.id.ivImage);
            btnPlayVoice = view.findViewById(R.id.btnPlayVoice);
            seekVoice = view.findViewById(R.id.seekVoice);
            tvVoiceDuration = view.findViewById(R.id.tvVoiceDuration);
        }
    }
}
