package com.securechat.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.securechat.R;
import com.securechat.models.User;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserSearchAdapter extends RecyclerView.Adapter<UserSearchAdapter.UserViewHolder> {

    public interface OnUserClickListener {
        void onClick(User user);
    }

    private final List<User> users;
    private final OnUserClickListener listener;

    public UserSearchAdapter(List<User> users, OnUserClickListener listener) {
        this.users = users;
        this.listener = listener;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = users.get(position);
        holder.tvUsername.setText(user.getUsername());
        holder.tvEmail.setText(user.getEmail());

        if (user.getProfileImageUrl() != null && !user.getProfileImageUrl().isEmpty()) {
            holder.civAvatar.setVisibility(View.VISIBLE);
            holder.tvAvatar.setVisibility(View.GONE);
            Glide.with(holder.civAvatar.getContext())
                    .load(user.getProfileImageUrl())
                    .transform(new CircleCrop())
                    .into(holder.civAvatar);
        } else {
            holder.civAvatar.setVisibility(View.GONE);
            holder.tvAvatar.setVisibility(View.VISIBLE);
            if (user.getUsername() != null && !user.getUsername().isEmpty()) {
                holder.tvAvatar.setText(String.valueOf(user.getUsername().charAt(0)).toUpperCase());
            }
        }

        holder.itemView.setOnClickListener(v -> listener.onClick(user));
    }

    @Override
    public int getItemCount() { return users.size(); }

    static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView tvUsername, tvEmail, tvAvatar;
        CircleImageView civAvatar;

        UserViewHolder(View view) {
            super(view);
            tvUsername = view.findViewById(R.id.tvUsername);
            tvEmail = view.findViewById(R.id.tvEmail);
            tvAvatar = view.findViewById(R.id.tvAvatar);
            civAvatar = view.findViewById(R.id.civAvatar);
        }
    }
}
