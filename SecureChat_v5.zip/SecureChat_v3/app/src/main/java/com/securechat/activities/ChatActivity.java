package com.securechat.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.securechat.R;
import com.securechat.adapters.MessageAdapter;
import com.securechat.models.Message;
import com.securechat.utils.CryptoUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ChatActivity extends AppCompatActivity {

    // ── Cloudinary config ──────────────────────────────────
    private static final String CLOUD_NAME   = "dpnfeua6f";
    private static final String UPLOAD_PRESET = "securechat_upload";
    private static final String CLOUDINARY_URL =
            "https://api.cloudinary.com/v1_1/" + CLOUD_NAME + "/";

    // ── Views ──────────────────────────────────────────────
    private RecyclerView recyclerMessages;
    private EditText etMessage;
    private LinearLayout layoutReplyBar;
    private TextView tvReplyPreview;
    private ImageButton btnCancelReply, btnVoice, btnSend, btnImage;

    // ── Firebase ───────────────────────────────────────────
    private MessageAdapter adapter;
    private List<Message> messages = new ArrayList<>();
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String conversationId;
    private String otherUserId;
    private boolean isHidden;

    // ── Reply state ────────────────────────────────────────
    private Message replyingTo = null;

    // ── Voice recording ────────────────────────────────────
    private MediaRecorder mediaRecorder;
    private File voiceFile;
    private long voiceStartTime;
    private boolean isRecording = false;

    private static final int RECORD_AUDIO_PERMISSION = 201;

    private ActivityResultLauncher<Intent> imagePickerLauncher;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        mAuth = FirebaseAuth.getInstance();
        db    = FirebaseFirestore.getInstance();

        conversationId = getIntent().getStringExtra("conversation_id");
        String otherUserName = getIntent().getStringExtra("other_user_name");
        otherUserId = getIntent().getStringExtra("other_user_id");
        isHidden    = getIntent().getBooleanExtra("hidden", false);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(otherUserName != null ? otherUserName : "Chat");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerMessages = findViewById(R.id.recyclerMessages);
        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        recyclerMessages.setLayoutManager(lm);

        String currentUid = mAuth.getCurrentUser().getUid();
        adapter = new MessageAdapter(messages, currentUid,
                (msg, emoji) -> sendReaction(msg, emoji),
                msg -> startReply(msg));
        recyclerMessages.setAdapter(adapter);

        etMessage     = findViewById(R.id.etMessage);
        btnSend       = findViewById(R.id.btnSend);
        btnImage      = findViewById(R.id.btnImage);
        btnVoice      = findViewById(R.id.btnVoice);
        layoutReplyBar = findViewById(R.id.layoutReplyBar);
        tvReplyPreview = findViewById(R.id.tvReplyPreview);
        btnCancelReply = findViewById(R.id.btnCancelReply);

        btnSend.setOnClickListener(v -> sendTextMessage());
        btnImage.setOnClickListener(v -> pickImage());
        btnCancelReply.setOnClickListener(v -> cancelReply());

        // Hold to record voice
        btnVoice.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                startRecording();
            } else if (event.getAction() == MotionEvent.ACTION_UP
                    || event.getAction() == MotionEvent.ACTION_CANCEL) {
                stopRecordingAndSend(event.getAction() == MotionEvent.ACTION_CANCEL);
            }
            return true;
        });

        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        if (uri != null) uploadImageToCloudinary(uri);
                    }
                });

        if (conversationId == null) createConversation();
        else listenForMessages();
    }

    // ─── Reply ────────────────────────────────────────────

    private void startReply(Message msg) {
        replyingTo = msg;
        layoutReplyBar.setVisibility(View.VISIBLE);
        String preview = "voice".equals(msg.getType()) ? "🎤 Voice message"
                : "image".equals(msg.getType()) ? "🖼 Photo"
                : (msg.getText() != null ? msg.getText() : "");
        tvReplyPreview.setText("Replying: " + preview);
        etMessage.requestFocus();
    }

    private void cancelReply() {
        replyingTo = null;
        layoutReplyBar.setVisibility(View.GONE);
    }

    // ─── Voice Recording ─────────────────────────────────

    private void startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, RECORD_AUDIO_PERMISSION);
            return;
        }
        try {
            voiceFile = new File(getCacheDir(), "voice_" + UUID.randomUUID() + ".m4a");
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setOutputFile(voiceFile.getAbsolutePath());
            mediaRecorder.prepare();
            mediaRecorder.start();
            voiceStartTime = System.currentTimeMillis();
            isRecording = true;
            btnVoice.setAlpha(0.5f);
            Toast.makeText(this, "🔴 Recording...", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Recording failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopRecordingAndSend(boolean cancelled) {
        if (!isRecording) return;
        isRecording = false;
        btnVoice.setAlpha(1f);
        long duration = (System.currentTimeMillis() - voiceStartTime) / 1000;
        try {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;
        } catch (Exception e) { return; }

        if (cancelled || duration < 1) {
            Toast.makeText(this, "Recording cancelled", Toast.LENGTH_SHORT).show();
            return;
        }
        uploadVoiceToCloudinary(voiceFile, duration);
    }

    // ─── Cloudinary Upload ────────────────────────────────

    private void uploadImageToCloudinary(Uri imageUri) {
        Toast.makeText(this, "Uploading image...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                // Convert URI to temp file
                File tempFile = new File(getCacheDir(), "img_" + UUID.randomUUID() + ".jpg");
                try (java.io.InputStream in = getContentResolver().openInputStream(imageUri);
                     java.io.OutputStream out = new java.io.FileOutputStream(tempFile)) {
                    byte[] buf = new byte[4096];
                    int len;
                    while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                }
                String url = cloudinaryUpload(tempFile, "image");
                if (url != null) {
                    runOnUiThread(() -> saveMessageToFirestore(null, url, null, 0));
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Upload failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Upload error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void uploadVoiceToCloudinary(File file, long duration) {
        Toast.makeText(this, "Sending voice...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String url = cloudinaryUpload(file, "raw");
            if (url != null) {
                runOnUiThread(() -> saveMessageToFirestore(null, null, url, duration));
            } else {
                runOnUiThread(() -> Toast.makeText(this, "Voice upload failed", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    /**
     * Multipart upload to Cloudinary — returns secure_url or null on failure.
     * resourceType: "image" | "video" | "raw"
     */
    private String cloudinaryUpload(File file, String resourceType) {
        String boundary = "----FormBoundary" + UUID.randomUUID().toString().replace("-", "");
        try {
            URL url = new URL(CLOUDINARY_URL + resourceType + "/upload");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(60000);

            try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
                // upload_preset field
                dos.writeBytes("--" + boundary + "\r\n");
                dos.writeBytes("Content-Disposition: form-data; name=\"upload_preset\"\r\n\r\n");
                dos.writeBytes(UPLOAD_PRESET + "\r\n");

                // file field
                dos.writeBytes("--" + boundary + "\r\n");
                dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\""
                        + file.getName() + "\"\r\n");
                dos.writeBytes("Content-Type: application/octet-stream\r\n\r\n");
                try (FileInputStream fis = new FileInputStream(file)) {
                    byte[] buf = new byte[4096];
                    int len;
                    while ((len = fis.read(buf)) > 0) dos.write(buf, 0, len);
                }
                dos.writeBytes("\r\n--" + boundary + "--\r\n");
            }

            int code = conn.getResponseCode();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(
                    code == 200 ? conn.getInputStream() : conn.getErrorStream()))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
            }

            if (code == 200) {
                JSONObject json = new JSONObject(sb.toString());
                return json.getString("secure_url");
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    // ─── Firestore Save ───────────────────────────────────

    private void saveMessageToFirestore(String text, String imageUrl, String voiceUrl, long voiceDuration) {
        String currentUid = mAuth.getCurrentUser().getUid();
        Map<String, Object> msgMap = new HashMap<>();
        msgMap.put("senderId", currentUid);
        msgMap.put("timestamp", System.currentTimeMillis());

        if (imageUrl != null) {
            msgMap.put("imageUrl", imageUrl);
            msgMap.put("type", "image");
        } else if (voiceUrl != null) {
            msgMap.put("voiceUrl", voiceUrl);
            msgMap.put("voiceDuration", voiceDuration);
            msgMap.put("type", "voice");
        } else {
            try {
                msgMap.put("encryptedText", CryptoUtils.encrypt(text, conversationId));
            } catch (Exception e) {
                Toast.makeText(this, "Encryption error", Toast.LENGTH_SHORT).show();
                return;
            }
            msgMap.put("type", "text");
        }

        attachReplyFields(msgMap);

        db.collection("conversations").document(conversationId)
                .collection("messages").add(msgMap)
                .addOnSuccessListener(ref -> {
                    if (text != null) etMessage.setText("");
                    cancelReply();
                    String preview = imageUrl != null ? "📷 Photo"
                            : voiceUrl != null ? "🎤 Voice"
                            : "🔒 Encrypted message";
                    updateLastMessage(preview, currentUid);
                });
    }

    private void attachReplyFields(Map<String, Object> map) {
        if (replyingTo == null) return;
        map.put("replyToId", replyingTo.getId());
        map.put("replyToSenderId", replyingTo.getSenderId());
        String raw = "voice".equals(replyingTo.getType()) ? "🎤 Voice message"
                : "image".equals(replyingTo.getType()) ? "🖼 Photo"
                : (replyingTo.getText() != null ? replyingTo.getText() : "");
        try { map.put("replyToText", CryptoUtils.encrypt(raw, conversationId)); }
        catch (Exception e) { map.put("replyToText", raw); }
    }

    // ─── Text & Image helpers ─────────────────────────────

    private void createConversation() {
        String currentUid = mAuth.getCurrentUser().getUid();
        String[] uids = {currentUid, otherUserId};
        java.util.Arrays.sort(uids);
        conversationId = uids[0] + "_" + uids[1] + (isHidden ? "_hidden" : "");
        listenForMessages();
    }

    private void listenForMessages() {
        db.collection("conversations").document(conversationId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;
                    messages.clear();
                    for (QueryDocumentSnapshot doc : snapshots) {
                        Message msg = doc.toObject(Message.class);
                        msg.setId(doc.getId());
                        if (!"image".equals(msg.getType()) && !"voice".equals(msg.getType())) {
                            try { msg.setText(CryptoUtils.decrypt(msg.getEncryptedText(), conversationId)); }
                            catch (Exception ex) { msg.setText("[encrypted]"); }
                        }
                        if (msg.getReplyToText() != null && !msg.getReplyToText().isEmpty()) {
                            try { msg.setReplyToDecryptedText(CryptoUtils.decrypt(msg.getReplyToText(), conversationId)); }
                            catch (Exception ex) { msg.setReplyToDecryptedText("🔒 message"); }
                        }
                        messages.add(msg);
                    }
                    adapter.notifyDataSetChanged();
                    if (!messages.isEmpty())
                        recyclerMessages.scrollToPosition(messages.size() - 1);
                });
    }

    private void sendTextMessage() {
        String text = etMessage.getText().toString().trim();
        if (text.isEmpty()) return;
        saveMessageToFirestore(text, null, null, 0);
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        imagePickerLauncher.launch(Intent.createChooser(intent, "Select Image"));
    }

    private void sendReaction(Message message, String emoji) {
        Map<String, Object> update = new HashMap<>();
        update.put("reactions." + mAuth.getCurrentUser().getUid(), emoji);
        db.collection("conversations").document(conversationId)
                .collection("messages").document(message.getId()).update(update);
    }

    private void updateLastMessage(String preview, String currentUid) {
        Map<String, Object> update = new HashMap<>();
        update.put("lastMessage", preview);
        update.put("lastTimestamp", System.currentTimeMillis());
        update.put("members", java.util.Arrays.asList(currentUid, otherUserId));
        update.put("hidden", isHidden);
        db.collection("conversations").document(conversationId)
                .set(update, com.google.firebase.firestore.SetOptions.merge());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        adapter.releasePlayer();
        if (mediaRecorder != null) { mediaRecorder.release(); mediaRecorder = null; }
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
