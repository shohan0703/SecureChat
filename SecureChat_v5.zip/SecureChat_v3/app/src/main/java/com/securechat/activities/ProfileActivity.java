package com.securechat.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.securechat.R;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    private static final String CLOUD_NAME    = "dpnfeua6f";
    private static final String UPLOAD_PRESET = "securechat_upload";
    private static final String CLOUDINARY_URL =
            "https://api.cloudinary.com/v1_1/" + CLOUD_NAME + "/image/upload";

    private CircleImageView civProfile;
    private TextView tvUsername, tvEmail;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String currentUid;

    private ActivityResultLauncher<Intent> imagePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        currentUid = mAuth.getCurrentUser().getUid();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        civProfile  = findViewById(R.id.civProfile);
        tvUsername  = findViewById(R.id.tvUsername);
        tvEmail     = findViewById(R.id.tvEmail);
        progressBar = findViewById(R.id.progressBar);
        Button btnChangePhoto = findViewById(R.id.btnChangePhoto);

        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        if (uri != null) uploadProfilePicture(uri);
                    }
                });

        btnChangePhoto.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            imagePickerLauncher.launch(Intent.createChooser(intent, "Select Photo"));
        });

        loadProfile();
    }

    private void loadProfile() {
        db.collection("users").document(currentUid).get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        tvUsername.setText(doc.getString("username"));
                        tvEmail.setText(doc.getString("email"));
                        String photoUrl = doc.getString("profileImageUrl");
                        if (photoUrl != null && !photoUrl.isEmpty()) {
                            Glide.with(this).load(photoUrl).transform(new CircleCrop()).into(civProfile);
                        }
                    }
                });
    }

    private void uploadProfilePicture(Uri imageUri) {
        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                // URI → temp file
                File tempFile = new File(getCacheDir(), "profile_" + UUID.randomUUID() + ".jpg");
                try (InputStream in = getContentResolver().openInputStream(imageUri);
                     FileOutputStream out = new FileOutputStream(tempFile)) {
                    byte[] buf = new byte[4096]; int len;
                    while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                }

                // Upload to Cloudinary
                String boundary = "----Boundary" + UUID.randomUUID().toString().replace("-", "");
                URL url = new URL(CLOUDINARY_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(60000);

                try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
                    dos.writeBytes("--" + boundary + "\r\n");
                    dos.writeBytes("Content-Disposition: form-data; name=\"upload_preset\"\r\n\r\n");
                    dos.writeBytes(UPLOAD_PRESET + "\r\n");

                    dos.writeBytes("--" + boundary + "\r\n");
                    dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"profile.jpg\"\r\n");
                    dos.writeBytes("Content-Type: application/octet-stream\r\n\r\n");
                    try (java.io.FileInputStream fis = new java.io.FileInputStream(tempFile)) {
                        byte[] buf = new byte[4096]; int len;
                        while ((len = fis.read(buf)) > 0) dos.write(buf, 0, len);
                    }
                    dos.writeBytes("\r\n--" + boundary + "--\r\n");
                }

                int code = conn.getResponseCode();
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(
                        code == 200 ? conn.getInputStream() : conn.getErrorStream()))) {
                    String line; while ((line = br.readLine()) != null) sb.append(line);
                }

                if (code == 200) {
                    String photoUrl = new JSONObject(sb.toString()).getString("secure_url");
                    db.collection("users").document(currentUid)
                            .update("profileImageUrl", photoUrl)
                            .addOnSuccessListener(unused -> runOnUiThread(() -> {
                                progressBar.setVisibility(View.GONE);
                                Glide.with(this).load(photoUrl).transform(new CircleCrop()).into(civProfile);
                                Toast.makeText(this, "Profile photo updated", Toast.LENGTH_SHORT).show();
                            }));
                } else {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(this, "Upload failed", Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
