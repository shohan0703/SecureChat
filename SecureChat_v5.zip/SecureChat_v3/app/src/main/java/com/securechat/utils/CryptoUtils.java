package com.securechat.utils;

import android.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;

/**
 * AES-256-CBC encryption for all messages.
 * The encryption key is derived from the conversation ID using SHA-256.
 * In production, use a proper key exchange (e.g. Diffie-Hellman or Signal Protocol).
 */
public class CryptoUtils {

    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    // Fixed IV for simplicity — in production, generate a random IV per message and prepend it
    private static final byte[] IV = "SecureChat16Byte".getBytes(StandardCharsets.UTF_8);

    private static SecretKey deriveKey(String conversationId) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] keyBytes = digest.digest(conversationId.getBytes(StandardCharsets.UTF_8));
        keyBytes = Arrays.copyOf(keyBytes, 32); // 256-bit key
        return new SecretKeySpec(keyBytes, "AES");
    }

    public static String encrypt(String plaintext, String conversationId) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(conversationId), new IvParameterSpec(IV));
        byte[] encrypted = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(encrypted, Base64.NO_WRAP);
    }

    public static String decrypt(String ciphertext, String conversationId) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, deriveKey(conversationId), new IvParameterSpec(IV));
        byte[] decoded = Base64.decode(ciphertext, Base64.NO_WRAP);
        return new String(cipher.doFinal(decoded), StandardCharsets.UTF_8);
    }
}
